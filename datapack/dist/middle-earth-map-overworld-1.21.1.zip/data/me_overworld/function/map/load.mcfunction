scoreboard objectives add me_map dummy
execute unless score #spawn_set me_map matches 1 run setworldspawn 29856 90 28800
scoreboard players set #spawn_set me_map 1
